#Author-Autodesk
#Description-Demonstrates the creation of a custom feature.

from pickletools import ArgumentDescriptor
from tkinter.messagebox import NO
from venv import create
import adsk.core, adsk.fusion, traceback
import logging
import os
from .decorators import eventHandler, HandlerCollection

appPath = os.path.dirname(os.path.abspath(__file__))

_handlerOn: bool = True

logger = logging.getLogger('CustomPocket')

for handler in logger.handlers:
    handler.flush()
    handler.close()
    logger.removeHandler(handler)

logger.setLevel(logging.WARNING)
formatter = logging.Formatter('%(asctime)s; %(name)s; %(levelname)s; %(lineno)d; %(funcName)s ; %(message)s')
logHandler = logging.FileHandler(os.path.join(appPath, 'customPocket.log'), mode='w')
logHandler.setFormatter(formatter)
logHandler.setLevel(logging.DEBUG)
logger.addHandler(logHandler)
logger.setLevel(logging.WARNING)

_app: adsk.core.Application = None
_ui: adsk.core.UserInterface = None

_customFeatureDef: adsk.fusion.CustomFeature = None

_edgeSelectInput: adsk.core.SelectionCommandInput = None
# _lengthInput: adsk.core.ValueCommandInput = None
# _widthInput: adsk.core.ValueCommandInput = None
# _depthInput: adsk.core.ValueCommandInput = None
_radiusInput: adsk.core.ValueCommandInput = None

_alreadyCreatedCustomFeature: adsk.fusion.CustomFeature = None
_restoreTimelineObject: adsk.fusion.TimelineObject = None
_alreadyCreated: bool = False
_isRolledForEdit = False


def run(context):
    try:
        global _app, _ui
        _app = adsk.core.Application.get()
        _ui  = _app.userInterface
        handlerGroup = 'run'
        logger.debug("Running")
        # Create the command definition for the creation command.
        createCmdDef = _ui.commandDefinitions.addButtonDefinition('adskCustomPocketCreate', 
                                                                    'Custom Pocket', 
                                                                    'Adds a pocket at a point.', 
                                                                    'Resources/CustomPocket')    

        # Add the create button after the Emboss command in the CREATE panel of the SOLID tab.
        solidWS = _ui.workspaces.itemById('FusionSolidEnvironment')
        panel = solidWS.toolbarPanels.itemById('SolidCreatePanel')
        btncontrol = panel.controls.addCommand(createCmdDef, 'EmbossCmd', False).isPromoted = True
        # btncontrol.isPromoted = True      

        # Create the command definition for the edit command.
        editCmdDef = _ui.commandDefinitions.addButtonDefinition('adskCustomPocketEdit', 
                                                                'Edit Custom Pocket', 
                                                                'Edit custom pocket.', '')        

        # Connect to the command created event for the create command.
        HandlerCollection.remove(groupId =  handlerGroup)
        CreatePocketCommandCreatedHandler(event = createCmdDef.commandCreated, groupId =  handlerGroup)

        # Connect to the command created event for the edit command.
        EditPocketCommandCreatedHandler(event = editCmdDef.commandCreated, groupId =  handlerGroup)

        # Create the custom feature definition.
        global _customFeatureDef
        _customFeatureDef = adsk.fusion.CustomFeatureDefinition.create('adskCustomPocket', 
                                                                        'Custom Pocket', 
                                                                        'Resources/CustomPocket')
        _customFeatureDef.editCommandId = 'adskCustomPocketEdit'

        # Connect to the compute event for the custom feature.
        ComputeCustomFeature(event = _customFeatureDef.customFeatureCompute, groupId =  handlerGroup)
    except:
        logger.exception('Exception')
        showMessage('Run Failed:\n{}'.format(traceback.format_exc()))


def stop(context):
    logger.debug('Stopping')
    for handler in logger.handlers:
        handler.flush()
        handler.close()
        logger.removeHandler(handler)
    try:
        # Remove all UI elements.
        logger.debug('Stopping')
        solidWS = _ui.workspaces.itemById('FusionSolidEnvironment')
        panel = solidWS.toolbarPanels.itemById('SolidCreatePanel')
        cntrl = panel.controls.itemById('adskCustomPocketCreate')
        if cntrl:
            cntrl.deleteMe()
            
        cmdDef = _ui.commandDefinitions.itemById('adskCustomPocketCreate')
        if cmdDef:
            cmdDef.deleteMe()

        cmdDef = _ui.commandDefinitions.itemById('adskCustomPocketEdit')
        if cmdDef:
            cmdDef.deleteMe()

        HandlerCollection.remove()
    except:
        logger.exception('Exception')
        showMessage('Stop Failed:\n{}'.format(traceback.format_exc()))


# Define the command inputs needed to get the input from the user for the
# creation of the feauture and connect to the command related events.
@eventHandler(handler_cls = adsk.core.CommandCreatedEventHandler)
def CreatePocketCommandCreatedHandler(eventArgs: adsk.core.CommandCreatedEventArgs):
    try:
        logger.debug('Creating Pocket Command')
        handlerGroup = 'CreatePocketCommandCreatedHandler'
        cmd = eventArgs.command
        inputs = cmd.commandInputs
        des: adsk.fusion.Design = _app.activeProduct

        global _edgeSelectInput, _radiusInput

        # Create the selection input to select the body(s).
        _edgeSelectInput = inputs.addSelectionInput('selectPoint', 
                                                        'Points', 
                                                        'Select point to define pocket position.')
        _edgeSelectInput.addSelectionFilter('Edges')
        _edgeSelectInput.tooltip = 'Select edge to define the bevel.'
        _edgeSelectInput.setSelectionLimits(1, 1)

        # Create the value input to get the length.
        # length = adsk.core.ValueInput.createByReal(5)
        lengthUnits = des.unitsManager.defaultLengthUnits
        # _lengthInput = inputs.addValueInput('length', 'Length', lengthUnits, length)

        # # Create the value input to get the width.
        # width = adsk.core.ValueInput.createByReal(3)
        # _widthInput = inputs.addValueInput('width', 'Width', lengthUnits, width)

        # # Create the value input to get the depth.
        # depth = adsk.core.ValueInput.createByReal(1)
        # _depthInput = inputs.addValueInput('depth', 'Depth', lengthUnits, depth)

        # Create the value input to get the fillet radius.
        radius = adsk.core.ValueInput.createByReal(0.5)
        _radiusInput = inputs.addValueInput('cornerRadius', 'Corner Radius', lengthUnits, radius)
                                            
        # Connect to the needed command related events.
        HandlerCollection.remove(handlerGroup)
        ExecutePreviewHandler(event = cmd.executePreview, groupId =  handlerGroup)

        CreateExecuteHandler(event = cmd.execute, groupId =  handlerGroup)

        PreSelectHandler(event = cmd.preSelect, groupId =  handlerGroup)

        ValidateInputsHandler(event = cmd.validateInputs, groupId =  handlerGroup)
    except:
        logger.exception('Exception')
        showMessage('CommandCreated failed: {}\n'.format(traceback.format_exc()))


# Event handler for the validateInputs event.
@eventHandler(handler_cls = adsk.core.ValidateInputsEventHandler)
def ValidateInputsHandler(eventArgs: adsk.core.ValidateInputsEventArgs):
    logger.debug('ValidateInputsHandler')
    try:
        # Verify the inputs have valid expressions.
        if not all( [_radiusInput.isValidExpression] ):
            eventArgs.areInputsValid = False
            return

        # Verify the sizes are valid.
        # diam = _radiusInput.value * 2
        # if diam + 0.01 > _lengthInput.value or diam + 0.01 > _widthInput.value:
        #     eventArgs.areInputsValid = False
        #     return
    except:
        logger.exception('Exception')
        showMessage('ValidateInputsHandler: {}\n'.format(traceback.format_exc()))

        
# Event handler for the execute event of the create command.
@eventHandler(handler_cls = adsk.core.CommandEventHandler)
def CreateExecuteHandler(eventArgs: adsk.core.CommandEventArgs):
    global _alreadyCreated
    logger.debug('CreateExecuteHandler')
    try:
        # Create the body of the pocket.
        edge: adsk.fusion.BRepCoEdge = _edgeSelectInput.selection(0).entity

        des: adsk.fusion.Design = _app.activeProduct
        defLengthUnits = des.unitsManager.defaultLengthUnits

        edgeBevel = CreateBevel(edge, _radiusInput.value)

        comp = edge.body.parentComponent

        custFeatInput = comp.features.customFeatures.createInput(_customFeatureDef)

        radiusInput = adsk.core.ValueInput.createByString(_radiusInput.expression)             
        custFeatInput.addCustomParameter('radius', 'Radius', radiusInput,
                                            defLengthUnits, True)               

#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        custFeatInput.addDependency('edge', edge) #<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

        # Subtract the pocket from the parametric body.
        paramBody = edge.body
        comp = paramBody.parentComponent
        baseFeat = comp.features.baseFeatures.add()
        baseFeat.startEdit()
        comp.bRepBodies.add(edgeBevel, baseFeat)
        baseFeat.finishEdit()

        # Create a combine feature to subtract the pocket body from the part.
        combineFeature = None
        toolBodies = adsk.core.ObjectCollection.create()
        toolBodies.add(baseFeat.bodies.item(0))
        combineInput = comp.features.combineFeatures.createInput(paramBody, toolBodies)
        combineInput.isKeepToolBodies=True
        combineInput.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
        combineFeature = comp.features.combineFeatures.add(combineInput)
        
        # Create the custom feature input.
        des: adsk.fusion.Design = _app.activeProduct
        defLengthUnits = des.unitsManager.defaultLengthUnits
        custFeatInput.setStartAndEndFeatures(baseFeat, combineFeature)
        logger.debug(f'Execute - _alreadyCreated: {_alreadyCreated}')
        _handlerOn = False
        logger.debug(f'Execute - _alreadyCreated: {_alreadyCreated}')
        comp.features.customFeatures.add(custFeatInput)
        _handlerOn = True
    except:
        logger.exception('Exception')
        eventArgs.executeFailed = True
        showMessage('Execute: {}\n'.format(traceback.format_exc()))


@eventHandler(handler_cls = adsk.core.CommandCreatedEventHandler)
def EditPocketCommandCreatedHandler(eventArgs: adsk.core.CommandCreatedEventArgs):
    global _alreadyCreated
    logger.debug('Edit Command created')
    try:
        _handlerOn = True
        handlerGroup = 'EditPocketCommandCreatedHandler'
        cmd = eventArgs.command
        inputs = cmd.commandInputs
        des: adsk.fusion.Design = _app.activeProduct
        defLengthUnits = des.unitsManager.defaultLengthUnits

        # Get the currently selected custom feature.
        global _alreadyCreatedCustomFeature
        _alreadyCreatedCustomFeature = _ui.activeSelections.item(0).entity
        if _alreadyCreatedCustomFeature is None:
            return

        global _edgeSelectInput, _radiusInput

        # Create the selection input to select the sketch point.
        _edgeSelectInput = inputs.addSelectionInput('selectPoint', 
                                                        'edge', 
                                                        'Select point to define pocket position.')
        _edgeSelectInput.addSelectionFilter('SketchPoints')
        _edgeSelectInput.tooltip = 'Select point to define the center of the pocket.'
        _edgeSelectInput.setSelectionLimits(1, 1)

        # Get the collection of custom parameters for this custom feature.
        params = _alreadyCreatedCustomFeature.parameters

        # Create the value input to get the fillet radius.
        radius = adsk.core.ValueInput.createByString(params.itemById('radius').expression)
        _radiusInput = inputs.addValueInput('cornerRadius', 'Corner Radius', defLengthUnits, radius)
                                            
        # Connect to the needed command related events.
        HandlerCollection.remove(handlerGroup)
        ExecutePreviewHandler(event = cmd.executePreview, groupId =  handlerGroup)

        EditExecuteHandler(event = cmd.execute, groupId =  handlerGroup)

        PreSelectHandler(event = cmd.preSelect, groupId =  handlerGroup)

        EditActivateHandler(event = cmd.activate, groupId =  handlerGroup)

        ValidateInputsHandler(event = cmd.validateInputs, groupId =  handlerGroup)
    except:
        logger.exception('Exception')
        showMessage('CommandCreated failed: {}\n'.format(traceback.format_exc()))


# Event handler for the activate event.
@eventHandler(handler_cls = adsk.core.CommandEventHandler)
def EditActivateHandler(eventArgs: adsk.core.CommandEventArgs):
    logger.debug('Edit Activate')
    try:
        des: adsk.fusion.Design = _app.activeProduct

        # Save the current position of the timeline.
        timeline = des.timeline
        markerPosition = timeline.markerPosition
        global _restoreTimelineObject, _isRolledForEdit
        _restoreTimelineObject = timeline.item(markerPosition - 1)

        # Roll the timeline to just before the custom feature being edited.
        _alreadyCreatedCustomFeature.timelineObject.rollTo(rollBefore = True)
        _isRolledForEdit = True

        # Define a transaction marker so the the roll is not aborted with each change.
        eventArgs.command.beginStep()

        # Get the point and add it to the selection input.
        edge = _alreadyCreatedCustomFeature.dependencies.itemById('edge').entity
        _edgeSelectInput.addSelection(edge)
    except:
        logger.exception('Exception')
        showMessage('Execute: {}\n'.format(traceback.format_exc()))


# Event handler for the execute event of the edit command.
@eventHandler(handler_cls = adsk.core.CommandEventHandler)
def EditExecuteHandler(eventArgs: adsk.core.CommandEventArgs):
    logger.debug('EditExecuteHandler')
    global _alreadyCreated
    try:
        global _alreadyCreatedCustomFeature

        edge = _edgeSelectInput.selection(0).entity
        _handlerOn = True

        # Update the parameters.
        params = _alreadyCreatedCustomFeature.parameters

        radiusParam = params.itemById('radius')
        radiusParam.expression = _radiusInput.expression

        # Update the feature.
        UpdatePocket(_alreadyCreatedCustomFeature)

        # Update the point dependency.
        dependency = _alreadyCreatedCustomFeature.dependencies.itemById('edge')
        dependency.entity = edge

        # Roll the timeline to its previous position.
        global _isRolledForEdit
        if _isRolledForEdit:
            _restoreTimelineObject.rollTo(False)
            _isRolledForEdit = False

        _alreadyCreatedCustomFeature = None


        showMessage('Finished ExecuteHandler')
    except:
        logger.exception('Exception')
        showMessage('Execute: {}\n'.format(traceback.format_exc()))


# Event handler for the executePreview event.
@eventHandler(handler_cls = adsk.core.CommandEventHandler)
def ExecutePreviewHandler(eventArgs: adsk.core.CommandEventArgs):
    logger.debug('Execute Preview')
    try:
        # Get the settings from the inputs.
        edge: adsk.fusion.BrepEdge = _edgeSelectInput.selection(0).entity
        radius = _radiusInput.value

        # Create the fillet feature.
        pocketBody = CreateBevel(edge, radius)

        # Create a base feature and add the body.
        paramBody = edge.body
        comp = paramBody.parentComponent

        baseFeat = comp.features.baseFeatures.add()
        baseFeat.startEdit()
        comp.bRepBodies.add(pocketBody, baseFeat)
        baseFeat.finishEdit()

        # Create a combine feature to subtract the pocket body from the part.
        toolBodies = adsk.core.ObjectCollection.create()
        toolBodies.add(baseFeat.bodies.item(0))
        combineInput = comp.features.combineFeatures.createInput(paramBody, toolBodies)
        combineInput.isKeepToolBodies = False
        combineInput.operation = adsk.fusion.FeatureOperations.CutFeatureOperation
        comp.features.combineFeatures.add(combineInput)
    except:
        logger.exception('Exception')
        showMessage('ExecutePreview: {}\n'.format(traceback.format_exc()))       


# Controls what the user can select when the command is running.
# This checks to make sure the point is on a planar face and the
# body the point is on is not an external reference.
@eventHandler(handler_cls = adsk.core.SelectionEventHandler)
def PreSelectHandler(eventArgs: adsk.core.SelectionEventArgs):
    logger.debug('PreSelect')
    try:
        edge: adsk.fusion.BrepEdge = eventArgs.selection.entity

        if edge is None:
            eventArgs.isSelectable = False
            return

        # Verify the body is not from an XRef.
        if edge.assemblyContext:
            occ = edge.assemblyContext
            if occ.isReferencedComponent:
                eventArgs.isSelectable = False
                return
    except:
        logger.exception('Exception')
        showMessage('PreSelectEventHandler: {}\n'.format(traceback.format_exc()))


# Event handler to handle the compute of the custom feature.
@eventHandler(handler_cls = adsk.fusion.CustomFeatureEventHandler)
def ComputeCustomFeature(args: adsk.fusion.CustomFeatureEventArgs):
    logger.debug('ComputeCustomFeature')
    try:
        global _handlerOn
        logger.debug(f'ComputeCustomFeature - _alreadyCreated: {_alreadyCreated}')
        if not _handlerOn:
            logger.debug(f'ComputeCustomFeature - returned short')
            return
        logger.debug(f'ComputeCustomFeature - _alreadyCreated: {_alreadyCreated}')
        # adsk.doEvents()
        eventArgs: adsk.fusion.CustomFeatureEventArgs = args

        # Get the custom feature that is being computed.
        custFeature = eventArgs.customFeature

        # Get the original sketch point and the values from the custom feature.
        edge = custFeature.dependencies.itemById('edge').entity
        radius = custFeature.parameters.itemById('radius').value

        # Create a new temporary body for the pocket. 
        # This can return None when the point isn't on a face.
        pocketBody = CreateBevel(edge, radius)
        if pocketBody is None:
            # Add a failure status message because it failed to create the pocket.
            eventArgs.computeStatus.statusMessages.addError('DRPOINT_COMPUTE_FAILED', '')
            return
        
        # Get the existing base feature and update the body.
        baseFeature: adsk.fusion.BaseFeature = None
        for feature in custFeature.features:
            if feature.objectType == adsk.fusion.BaseFeature.classType():
                baseFeature = feature
                break        

        # Update the body in the base feature.
        baseFeature.startEdit()
        body: adsk.fusion.BRepBody = baseFeature.bodies.item(0)
        baseFeature.updateBody(body, pocketBody)
        baseFeature.finishEdit()
        adsk.doEvents()
    except:
        logger.exception('Exception')
        showMessage('CustomFeatureCompute: {}\n'.format(traceback.format_exc()))


# Utility function that given the position and pocket size builds
# a temporary B-Rep body is the tool body to create the pocket.
def CreateBevel(edge: adsk.fusion.BRepEdge, radius):
    logger.debug('Creating pocketBody')
    try:
        if edge is None:
            return None

        # Define the pocket at the origin with the length in the X direction,
        # width in the Y direction, and depth in the -Z direction.
        tBRep: adsk.fusion.TemporaryBRepManager = adsk.fusion.TemporaryBRepManager.get()
        widthDir = adsk.core.Vector3D.create(0, 1, 0)
        startPoint:adsk.fusion.Point3D = None
        endPoint:adsk.fusion.Point3D = None
        face1 = edge.faces.item(0)
        _, startPoint, endPoint = edge.evaluator.getEndPoints()
        
        bodies = []
        bodies.append(tBRep.createCylinderOrCone(startPoint, radius,
                                                endPoint, radius ))                                                

        # Combine the bodies into a single body.
        newBody: adsk.fusion.BRepBody = None
        for body in bodies:
            if newBody is None:
                newBody = body
            else:
                tBRep.booleanOperation(newBody, body, adsk.fusion.BooleanTypes.UnionBooleanType)

        return newBody
    except:
        logger.exception('Exception')
        showMessage('CreateBevel: {}\n'.format(traceback.format_exc()))


# Updates an existing custom pocket feature.
def UpdatePocket(customFeature: adsk.fusion.CustomFeature) -> bool:
    logger.debug('UpdatePocket')
    try:
        # Get the original sketch point and the values from the custom feature.
        edge: adsk.fusion.BrepEdge = customFeature.dependencies.itemById('edge').entity

        radius = customFeature.parameters.itemById('radius').value

        # Create a new temporary body for the pocket. This can return None when the point isn't on a face.
        pocketBody = CreateBevel(edge, radius)
        if pocketBody is None:
            return False
        
        # Get the existing base feature and update the body.
        baseFeature: adsk.fusion.BaseFeature = None
        for feature in customFeature.features:
            if feature.objectType == adsk.fusion.BaseFeature.classType():
                baseFeature = feature
                break        

        # Update the body in the base feature.
        baseFeature.startEdit()
        body: adsk.fusion.BRepBody = baseFeature.bodies.item(0)
        baseFeature.updateBody(body, pocketBody)
        baseFeature.finishEdit()
        return True
    except:
        logger.exception('Exception')
        showMessage('UpdateFillet: {}\n'.format(traceback.format_exc()))
        return False


# Get the face the selected point lies on. This assumes the point is
# in root component space. The returned face will be in the context
# of the root component.
#
# There is a case where more than one face can be found but in this case
# None is returned. The case is when the point is very near the edge of
# the face so it is ambiguous which face the point is on.
def GetFaceUnderPoint(point: adsk.core.Point3D) -> adsk.fusion.BRepFace:
    des: adsk.fusion.Design = _app.activeProduct
    root = des.rootComponent

    foundFaces: adsk.core.ObjectCollection = root.findBRepUsingPoint(point, adsk.fusion.BRepEntityTypes.BRepFaceEntityType, 0.01, True)
    if foundFaces.count == 0:
        return None
    face: adsk.fusion.BRepFace = foundFaces.item(0)
    return face

def showMessage(message, error = False):
    textPalette: adsk.core.TextCommandPalette = _ui.palettes.itemById('TextCommands')
    textPalette.writeText(message)

    if error:
        _ui.messageBox(message)